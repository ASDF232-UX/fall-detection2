# NLOS-mmWave-Fall-Detection
Designed a system of mmWave radars to detect user fall events in a single room environment. Used both ML approaches namely, LSTM (Long Short-Term Memory) and PointNet++, and centroid based non-ML algorithmic approach to classify the human point cloud data for fall detection purposes.
